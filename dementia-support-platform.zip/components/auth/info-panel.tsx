import { Brain, Puzzle, MessageCircleHeart, HeartPulse } from 'lucide-react'

const highlights = [
  {
    icon: Puzzle,
    title: 'Cognitive games',
    description:
      'Gentle, science-backed exercises that keep memory, focus, and reasoning active—at a comfortable pace.',
  },
  {
    icon: MessageCircleHeart,
    title: 'AI companion',
    description:
      'A patient, always-available assistant that offers reminders, reassurance, and calm conversation.',
  },
  {
    icon: HeartPulse,
    title: 'For patients & carers',
    description:
      'Track progress, spot changes early, and share meaningful moments with the people who care.',
  },
]

export function InfoPanel() {
  return (
    <section className="relative flex flex-col justify-between overflow-hidden p-8 lg:p-12">
      {/* Hero image with gradient overlay */}
      <div className="absolute inset-0 -z-10">
        <img
          src="/care-hero.png"
          alt="A caregiver gently holding the hands of an elderly loved one"
          className="h-full w-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/60 to-transparent" />
      </div>

      {/* Brand */}
      <div className="flex items-center gap-3">
        <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <Brain className="size-5" aria-hidden="true" />
        </span>
        <span className="font-heading text-xl font-bold tracking-tight">Lumen</span>
      </div>

      {/* Headline + explanation */}
      <div className="max-w-xl py-12">
        <span className="inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
          Memory care, made gentle
        </span>
        <h1 className="mt-5 text-balance font-heading text-4xl font-bold leading-tight tracking-tight lg:text-5xl">
          Bringing clarity to life with dementia
        </h1>
        <p className="mt-5 text-pretty leading-relaxed text-muted-foreground lg:text-lg">
          Dementia gradually affects memory, thinking, language, and mood—making
          everyday tasks harder and moments of confusion more frequent. It is
          isolating, both for those diagnosed and the people who love them. Lumen
          brings warmth and structure to each day with supportive tools designed
          around dignity, not difficulty.
        </p>

        <ul className="mt-8 grid gap-4">
          {highlights.map(({ icon: Icon, title, description }) => (
            <li key={title} className="flex gap-4">
              <span className="mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <div>
                <p className="font-heading font-semibold">{title}</p>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {description}
                </p>
              </div>
            </li>
          ))}
        </ul>
      </div>

      <p className="text-sm text-muted-foreground">
        Not a medical device. Lumen complements—never replaces—professional care.
      </p>
    </section>
  )
}
